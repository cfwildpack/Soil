# Website Eksplorasi Tanah

Website sederhana bertema tanah menggunakan HTML, CSS, dan JavaScript.

## Fitur
- Menampilkan berbagai jenis tanah
- Fitur pencarian
- Tampilan sederhana dan bersih

## Cara Menjalankan
Buka file index.html di browser.

## Teknologi
- HTML
- CSS
- JavaScript
