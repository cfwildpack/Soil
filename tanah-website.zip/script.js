const soils = [
  { name: "Tanah Humus", desc: "Subur dan kaya bahan organik." },
  { name: "Tanah Liat", desc: "Lengket dan sulit menyerap air." },
  { name: "Tanah Pasir", desc: "Berbutir kasar dan cepat menyerap air." },
  { name: "Tanah Gambut", desc: "Berwarna gelap dan kaya bahan organik." },
  { name: "Tanah Kapur", desc: "Mengandung kalsium tinggi dan kurang subur." }
];

const container = document.getElementById("soil-container");
const searchInput = document.getElementById("search");

function displaySoils(data) {
  container.innerHTML = "";
  data.forEach(soil => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.innerHTML = `<h3>${soil.name}</h3><p>${soil.desc}</p>`;
    container.appendChild(card);
  });
}

searchInput.addEventListener("input", (e) => {
  const value = e.target.value.toLowerCase();
  const filtered = soils.filter(s => s.name.toLowerCase().includes(value));
  displaySoils(filtered);
});

displaySoils(soils);
